-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS springbootprojecthugo;

-- Seleccionar la base de datos
USE springbootprojecthugo;

-- Crear la tabla Departamento
CREATE TABLE IF NOT EXISTS departamento (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(255)
);

-- Crear la tabla Empleado
CREATE TABLE IF NOT EXISTS empleado (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(255),
    salario DOUBLE,
    departamento_id INT,
    FOREIGN KEY (departamento_id) REFERENCES departamento(id)
);

-- Insertar datos en la tabla Departamento
INSERT INTO departamento (nombre) VALUES ('Ventas');
INSERT INTO departamento (nombre) VALUES ('TI');

-- Insertar datos en la tabla Empleado
INSERT INTO empleado (nombre, salario, departamento_id) VALUES ('Juan Pérez', 50000, 1);
INSERT INTO empleado (nombre, salario, departamento_id) VALUES ('Ana Rodríguez', 60000, 2);


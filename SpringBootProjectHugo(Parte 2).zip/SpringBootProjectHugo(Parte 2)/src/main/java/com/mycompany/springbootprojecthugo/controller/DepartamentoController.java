package com.mycompany.springbootprojecthugo.controller;

import com.mycompany.springbootprojecthugo.dto.DepartamentoDTO;
import com.mycompany.springbootprojecthugo.service.DepartamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador que maneja las operaciones relacionadas con los departamentos en
 * la API.
 */
@RestController
@RequestMapping("/api/departamentos")
public class DepartamentoController {

    @Autowired
    private DepartamentoService departamentoService;

    /**
     * Obtiene todos los departamentos.
     *
     * @return ResponseEntity con la lista de DepartamentoDTO y el código de
     * estado HTTP OK.
     */
    @GetMapping
    public ResponseEntity<List<DepartamentoDTO>> obtenerTodosDepartamentos() {
        List<DepartamentoDTO> departamentos = departamentoService.obtenerTodos();
        return new ResponseEntity<>(departamentos, HttpStatus.OK);
    }

    /**
     * Obtiene un departamento por su ID.
     *
     * @param id ID del departamento a obtener.
     * @return ResponseEntity con el DepartamentoDTO y el código de estado HTTP
     * OK.
     */
    @GetMapping("/{id}")
    public ResponseEntity<DepartamentoDTO> obtenerDepartamentoPorId(@PathVariable Long id) {
        DepartamentoDTO departamento = departamentoService.obtenerPorId(id);
        return new ResponseEntity<>(departamento, HttpStatus.OK);
    }

    /**
     * Crea un nuevo departamento.
     *
     * @param departamentoDTO Datos del nuevo departamento.
     * @return ResponseEntity con el DepartamentoDTO creado y el código de
     * estado HTTP CREATED.
     */
    @PostMapping
    public ResponseEntity<DepartamentoDTO> crearDepartamento(@RequestBody DepartamentoDTO departamentoDTO) {
        DepartamentoDTO nuevoDepartamento = departamentoService.crearDepartamento(departamentoDTO);
        return new ResponseEntity<>(nuevoDepartamento, HttpStatus.CREATED);
    }

    /**
     * Actualiza un departamento existente por su ID.
     *
     * @param id ID del departamento a actualizar.
     * @param departamentoDTO Datos actualizados del departamento.
     * @return ResponseEntity con el DepartamentoDTO actualizado y el código de
     * estado HTTP OK.
     */
    @PutMapping("/{id}")
    public ResponseEntity<DepartamentoDTO> actualizarDepartamento(@PathVariable Long id, @RequestBody DepartamentoDTO departamentoDTO) {
        DepartamentoDTO departamentoActualizado = departamentoService.actualizarDepartamento(id, departamentoDTO);
        return new ResponseEntity<>(departamentoActualizado, HttpStatus.OK);
    }

    /**
     * Elimina un departamento por su ID.
     *
     * @param id ID del departamento a eliminar.
     * @return ResponseEntity con el código de estado HTTP NO_CONTENT.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDepartamento(@PathVariable Long id) {
        departamentoService.eliminarDepartamento(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

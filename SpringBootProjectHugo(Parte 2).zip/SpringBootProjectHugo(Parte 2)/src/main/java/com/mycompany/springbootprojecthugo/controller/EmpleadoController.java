package com.mycompany.springbootprojecthugo.controller;

import com.mycompany.springbootprojecthugo.dto.EmpleadoDTO;
import com.mycompany.springbootprojecthugo.service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador que maneja las operaciones relacionadas con los empleados en la
 * API.
 */
@RestController
@RequestMapping("/api/empleados")
public class EmpleadoController {

    @Autowired
    private EmpleadoService empleadoService;

    /**
     * Obtiene todos los empleados.
     *
     * @return ResponseEntity con la lista de EmpleadoDTO y el código de estado
     * HTTP OK.
     */
    @GetMapping
    public ResponseEntity<List<EmpleadoDTO>> obtenerTodosEmpleados() {
        List<EmpleadoDTO> empleados = empleadoService.obtenerTodos();
        return new ResponseEntity<>(empleados, HttpStatus.OK);
    }

    /**
     * Obtiene un empleado por su ID.
     *
     * @param id ID del empleado a obtener.
     * @return ResponseEntity con el EmpleadoDTO y el código de estado HTTP OK.
     */
    @GetMapping("/{id}")
    public ResponseEntity<EmpleadoDTO> obtenerEmpleadoPorId(@PathVariable Long id) {
        EmpleadoDTO empleado = empleadoService.obtenerPorId(id);
        return new ResponseEntity<>(empleado, HttpStatus.OK);
    }

    /**
     * Crea un nuevo empleado.
     *
     * @param empleadoDTO Datos del nuevo empleado.
     * @return ResponseEntity con el EmpleadoDTO creado y el código de estado
     * HTTP CREATED.
     */
    @PostMapping
    public ResponseEntity<EmpleadoDTO> crearEmpleado(@RequestBody EmpleadoDTO empleadoDTO) {
        EmpleadoDTO nuevoEmpleado = empleadoService.crearEmpleado(empleadoDTO);
        return new ResponseEntity<>(nuevoEmpleado, HttpStatus.CREATED);
    }

    /**
     * Actualiza un empleado existente por su ID.
     *
     * @param id ID del empleado a actualizar.
     * @param empleadoDTO Datos actualizados del empleado.
     * @return ResponseEntity con el EmpleadoDTO actualizado y el código de
     * estado HTTP OK.
     */
    @PutMapping("/{id}")
    public ResponseEntity<EmpleadoDTO> actualizarEmpleado(@PathVariable Long id, @RequestBody EmpleadoDTO empleadoDTO) {
        EmpleadoDTO empleadoActualizado = empleadoService.actualizarEmpleado(id, empleadoDTO);
        return new ResponseEntity<>(empleadoActualizado, HttpStatus.OK);
    }

    /**
     * Elimina un empleado por su ID.
     *
     * @param id ID del empleado a eliminar.
     * @return ResponseEntity con el código de estado HTTP NO_CONTENT.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEmpleado(@PathVariable Long id) {
        empleadoService.eliminarEmpleado(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

package com.mycompany.springbootprojecthugo.dto;

/**
 * DTO (Data Transfer Object) que representa un departamento en la aplicación.
 */
public class DepartamentoDTO {

    private Long id;
    private String nombre;

    /**
     * Constructor predeterminado sin argumentos.
     */
    public DepartamentoDTO() {
    }

    /**
     * Constructor que inicializa un objeto DepartamentoDTO con valores específicos.
     *
     * @param id     El identificador único del departamento.
     * @param nombre El nombre del departamento.
     */
    public DepartamentoDTO(Long id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    /**
     * Obtiene el identificador único del departamento.
     *
     * @return El identificador único del departamento.
     */
    public Long getId() {
        return id;
    }

    /**
     * Establece el identificador único del departamento.
     *
     * @param id El identificador único del departamento.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre del departamento.
     *
     * @return El nombre del departamento.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del departamento.
     *
     * @param nombre El nombre del departamento.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}

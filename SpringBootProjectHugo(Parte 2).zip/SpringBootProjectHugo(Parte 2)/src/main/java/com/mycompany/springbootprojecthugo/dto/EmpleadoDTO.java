package com.mycompany.springbootprojecthugo.dto;

/**
 * DTO (Data Transfer Object) que representa un empleado en la aplicación.
 */
public class EmpleadoDTO {

    private Long id;
    private String nombre;
    private double salario;

    /**
     * Constructor predeterminado sin argumentos.
     */
    public EmpleadoDTO() {
    }

    /**
     * Constructor que inicializa un objeto EmpleadoDTO con valores
     * específicos.
     *
     * @param id El identificador único del empleado.
     * @param nombre El nombre del empleado.
     * @param salario El salario del empleado.
     */
    public EmpleadoDTO(Long id, String nombre, double salario) {
        this.id = id;
        this.nombre = nombre;
        this.salario = salario;
    }

    /**
     * Obtiene el identificador único del empleado.
     *
     * @return El identificador único del empleado.
     */
    public Long getId() {
        return id;
    }

    /**
     * Establece el identificador único del empleado.
     *
     * @param id El identificador único del empleado.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre del empleado.
     *
     * @return El nombre del empleado.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del empleado.
     *
     * @param nombre El nombre del empleado.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el salario del empleado.
     *
     * @return El salario del empleado.
     */
    public double getSalario() {
        return salario;
    }

    /**
     * Establece el salario del empleado.
     *
     * @param salario El salario del empleado.
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }
}

package com.mycompany.springbootprojecthugo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Clase que representa la entidad "Departamento" en la base de datos.
 */
@Entity
public class Departamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    /**
     * Constructor predeterminado sin argumentos.
     */
    public Departamento() {
    }

    /**
     * Constructor que inicializa un objeto Departamento con un nombre
     * específico.
     *
     * @param nombre El nombre del departamento.
     */
    public Departamento(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el identificador único del departamento.
     *
     * @return El identificador único del departamento.
     */
    public Long getId() {
        return id;
    }

    /**
     * Establece el identificador único del departamento.
     *
     * @param id El identificador único del departamento.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre del departamento.
     *
     * @return El nombre del departamento.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del departamento.
     *
     * @param nombre El nombre del departamento.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}

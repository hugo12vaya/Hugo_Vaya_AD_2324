package com.mycompany.springbootprojecthugo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Clase que representa la entidad "Empleado" en la base de datos.
 */
@Entity
public class Empleado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private double salario;

    /**
     * Constructor predeterminado sin argumentos.
     */
    public Empleado() {
    }

    /**
     * Constructor que inicializa un objeto Empleado con un nombre y salario
     * específicos.
     *
     * @param nombre El nombre del empleado.
     * @param salario El salario del empleado.
     */
    public Empleado(String nombre, double salario) {
        this.nombre = nombre;
        this.salario = salario;
    }

    /**
     * Obtiene el identificador único del empleado.
     *
     * @return El identificador único del empleado.
     */
    public Long getId() {
        return id;
    }

    /**
     * Establece el identificador único del empleado.
     *
     * @param id El identificador único del empleado.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre del empleado.
     *
     * @return El nombre del empleado.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del empleado.
     *
     * @param nombre El nombre del empleado.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el salario del empleado.
     *
     * @return El salario del empleado.
     */
    public double getSalario() {
        return salario;
    }

    /**
     * Establece el salario del empleado.
     *
     * @param salario El salario del empleado.
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }
}

package com.mycompany.springbootprojecthugo.repository;

import com.mycompany.springbootprojecthugo.model.Departamento;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Interfaz que define un repositorio para la entidad Departamento en la base de
 * datos.
 */
public interface DepartamentoRepository extends JpaRepository<Departamento, Long> {

    // Puedes agregar consultas personalizadas si es necesario
    /**
     * Elimina un departamento por su identificador �nico.
     *
     * @param id El identificador �nico del departamento a eliminar.
     */
    void deleteById(Long id);

    public Optional<Departamento> findById(Long id);
}

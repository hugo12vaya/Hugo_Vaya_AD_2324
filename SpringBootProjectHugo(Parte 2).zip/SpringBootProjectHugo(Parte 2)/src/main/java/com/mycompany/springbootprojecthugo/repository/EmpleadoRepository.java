package com.mycompany.springbootprojecthugo.repository;

import com.mycompany.springbootprojecthugo.model.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Interfaz que define un repositorio para la entidad Empleado en la base de datos.
 */
public interface EmpleadoRepository extends JpaRepository<Empleado, Long> {

    // Puedes agregar consultas personalizadas si es necesario

    /**
     * Elimina un empleado por su identificador �nico.
     *
     * @param id El identificador �nico del empleado a eliminar.
     */
    void deleteById(Long id);
}

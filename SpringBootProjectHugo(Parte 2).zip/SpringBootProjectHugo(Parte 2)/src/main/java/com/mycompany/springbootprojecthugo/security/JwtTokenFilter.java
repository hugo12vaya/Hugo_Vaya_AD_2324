package com.mycompany.springbootprojecthugo.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Filtro para validar y procesar el token JWT en cada solicitud.
 */
public class JwtTokenFilter extends UsernamePasswordAuthenticationFilter {

    private final JwtTokenProvider jwtTokenProvider;

    /**
     * Constructor que recibe un proveedor de tokens JWT.
     *
     * @param jwtTokenProvider El proveedor de tokens JWT.
     */
    public JwtTokenFilter(JwtTokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    /**
     * M�todo que realiza la l�gica del filtro.
     *
     * @param request  La solicitud HTTP.
     * @param response La respuesta HTTP.
     * @param chain    Cadena de filtros para continuar el procesamiento.
     * @throws ServletException Si hay un error de servlet.
     * @throws IOException      Si hay un error de entrada/salida.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        try {
            // L�gica para validar y procesar el token JWT
            Authentication authentication = jwtTokenProvider.getAuthenticationFromToken(request);

            if (authentication != null) {
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }

            // Continuar con la cadena de filtros
            chain.doFilter(request, response);
        } catch (Exception e) {
            // Manejar excepciones aqu�
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("Error al procesar el token JWT: " + e.getMessage());
            return;
        }
    }
}

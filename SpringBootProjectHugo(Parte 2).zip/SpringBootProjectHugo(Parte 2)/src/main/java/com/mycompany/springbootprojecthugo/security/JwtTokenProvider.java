package com.mycompany.springbootprojecthugo.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * Proveedor de tokens JWT para la autenticaci�n y autorizaci�n en la aplicaci�n.
 */
@Component
public class JwtTokenProvider {

    @Value("${app.jwt.secret}")
    private String jwtSecret;

    @Value("${app.jwt.expiration}")
    private int jwtExpiration;

    /**
     * Genera un token JWT a partir de la informaci�n de autenticaci�n del usuario.
     *
     * @param authentication La informaci�n de autenticaci�n del usuario.
     * @return El token JWT generado.
     */
    public String generateToken(Authentication authentication) {
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        Date now = new Date();
        Date expirationDate = new Date(now.getTime() + jwtExpiration);

        return Jwts.builder()
                .setSubject(Long.toString(userDetails.getId()))
                .setIssuedAt(now)
                .setExpiration(expirationDate)
                .signWith(SignatureAlgorithm.HS512, jwtSecret)
                .compact();
    }

    /**
     * Obtiene el ID de usuario a partir de un token JWT.
     *
     * @param token El token JWT.
     * @return El ID de usuario.
     */
    public Long getUserIdFromToken(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(jwtSecret)
                .parseClaimsJws(token)
                .getBody();

        return Long.parseLong(claims.getSubject());
    }

    /**
     * Valida si un token JWT es v�lido.
     *
     * @param token El token JWT a validar.
     * @return `true` si el token es v�lido, `false` en caso contrario.
     */
    public boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Obtiene la autenticaci�n a partir de un token JWT en la solicitud HTTP.
     *
     * @param request La solicitud HTTP.
     * @return La autenticaci�n del usuario.
     */
    public static Authentication getAuthenticationFromToken(HttpServletRequest request) {
        String token = JwtTokenProvider.resolveToken(request);
        if (token != null && JwtTokenProvider.validateToken(token)) {
            Long userId = JwtTokenProvider.getUserIdFromToken(token);
            UserDetailsImpl userDetails = new UserDetailsImpl(userId);
            return userDetails.toAuthentication();
        }
        return null;
    }

    /**
     * Resuelve el token JWT de la solicitud HTTP.
     *
     * @param request La solicitud HTTP.
     * @return El token JWT.
     */
    private static String resolveToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}

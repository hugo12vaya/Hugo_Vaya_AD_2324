package com.mycompany.springbootprojecthugo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Configuraci�n de seguridad para la aplicaci�n Spring Boot.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final JwtTokenProvider jwtTokenProvider;

    /**
     * Constructor que recibe el proveedor de tokens JWT como par�metro.
     *
     * @param jwtTokenProvider El proveedor de tokens JWT.
     */
    public SecurityConfig(JwtTokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    /**
     * Configuraci�n de reglas de autorizaci�n y autenticaci�n.
     *
     * @param http El objeto HttpSecurity que se configura.
     * @throws Exception Si hay un error durante la configuraci�n.
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .authorizeRequests()
                .antMatchers("/api/public/**").permitAll()
                .anyRequest().authenticated();

        // Agregar el filtro JwtTokenFilter antes del filtro de autenticaci�n de usuario y contrase�a
        http.addFilterBefore(new JwtTokenFilter(jwtTokenProvider), UsernamePasswordAuthenticationFilter.class);
    }

    // Otras configuraciones o proveedores de autenticaci�n si es necesario
}

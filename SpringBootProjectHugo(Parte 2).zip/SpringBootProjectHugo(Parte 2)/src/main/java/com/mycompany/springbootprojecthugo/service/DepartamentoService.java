package com.mycompany.springbootprojecthugo.service;

import com.mycompany.springbootprojecthugo.dto.DepartamentoDTO;
import com.mycompany.springbootprojecthugo.model.Departamento;
import com.mycompany.springbootprojecthugo.repository.DepartamentoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Servicio que gestiona operaciones relacionadas con la entidad Departamento.
 */
@Service
public class DepartamentoService {

    private final DepartamentoRepository departamentoRepository;
    private final ModelMapper modelMapper;

    /**
     * Constructor del servicio.
     *
     * @param departamentoRepository Repositorio de Departamento.
     * @param modelMapper            Componente para realizar mapeo entre objetos.
     */
    public DepartamentoService(DepartamentoRepository departamentoRepository, ModelMapper modelMapper) {
        this.departamentoRepository = Objects.requireNonNull(departamentoRepository, "departamentoRepository no debe ser nulo");
        this.modelMapper = Objects.requireNonNull(modelMapper, "modelMapper no debe ser nulo");
    }

    /**
     * Obtiene todos los departamentos.
     *
     * @return Lista de DepartamentoDTO.
     */
    public List<DepartamentoDTO> obtenerTodos() {
        List<Departamento> departamentos = departamentoRepository.findAll();
        return departamentos.stream()
                .map(this::convertirADepartamentoDTO)
                .collect(Collectors.toList());
    }

    /**
     * Obtiene un departamento por su identificador �nico.
     *
     * @param id Identificador �nico del departamento.
     * @return DepartamentoDTO correspondiente al ID proporcionado.
     * @throws ResponseStatusException Si no se encuentra el departamento con el ID dado.
     */
    public DepartamentoDTO obtenerPorId(Long id) {
        Optional<Departamento> optionalDepartamento = departamentoRepository.findById(id);
        Departamento departamento = optionalDepartamento.orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Departamento no encontrado con ID: " + id));
        return convertirADepartamentoDTO(departamento);
    }

    /**
     * Crea o actualiza un departamento.
     *
     * @param departamentoDTO DTO que contiene la informaci�n del departamento.
     * @return DepartamentoDTO del departamento creado o actualizado.
     */
    public DepartamentoDTO guardarDepartamento(DepartamentoDTO departamentoDTO) {
        Departamento departamento = convertirADepartamentoEntity(departamentoDTO);
        departamento = departamentoRepository.save(departamento);
        return convertirADepartamentoDTO(departamento);
    }

    /**
     * Crea un nuevo departamento.
     *
     * @param departamentoDTO DTO que contiene la informaci�n del nuevo departamento.
     * @return DepartamentoDTO del departamento creado.
     */
    public DepartamentoDTO crearDepartamento(DepartamentoDTO departamentoDTO) {
        return guardarDepartamento(departamentoDTO);
    }

    /**
     * Actualiza la informaci�n de un departamento existente.
     *
     * @param id              Identificador �nico del departamento a actualizar.
     * @param departamentoDTO DTO con la nueva informaci�n del departamento.
     * @return DepartamentoDTO actualizado.
     * @throws ResponseStatusException Si no se encuentra el departamento con el ID dado.
     */
    public DepartamentoDTO actualizarDepartamento(Long id, DepartamentoDTO departamentoDTO) {
        Departamento departamentoExistente = departamentoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Departamento no encontrado con ID: " + id));

        modelMapper.map(departamentoDTO, departamentoExistente);
        departamentoExistente.setId(id);

        return guardarDepartamento(convertirADepartamentoDTO(departamentoExistente));
    }

    /**
     * Elimina un departamento por su identificador �nico.
     *
     * @param id Identificador �nico del departamento a eliminar.
     */
    public void eliminarDepartamento(Long id) {
        departamentoRepository.deleteById(id);
    }

    private DepartamentoDTO convertirADepartamentoDTO(Departamento departamento) {
        return modelMapper.map(departamento, DepartamentoDTO.class);
    }

    private Departamento convertirADepartamentoEntity(DepartamentoDTO departamentoDTO) {
        return modelMapper.map(departamentoDTO, Departamento.class);
    }
}

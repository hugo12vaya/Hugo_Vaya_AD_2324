package com.mycompany.springbootprojecthugo.service;

import com.mycompany.springbootprojecthugo.dto.EmpleadoDTO;
import com.mycompany.springbootprojecthugo.model.Empleado;
import com.mycompany.springbootprojecthugo.repository.EmpleadoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Servicio que gestiona operaciones relacionadas con la entidad Empleado.
 */
@Service
public class EmpleadoService {

    private final EmpleadoRepository empleadoRepository;
    private final ModelMapper modelMapper;

    /**
     * Constructor del servicio.
     *
     * @param empleadoRepository Repositorio de Empleado.
     * @param modelMapper        Componente para realizar mapeo entre objetos.
     */
    @Autowired
    public EmpleadoService(EmpleadoRepository empleadoRepository, ModelMapper modelMapper) {
        this.empleadoRepository = Objects.requireNonNull(empleadoRepository, "empleadoRepository no debe ser nulo");
        this.modelMapper = Objects.requireNonNull(modelMapper, "modelMapper no debe ser nulo");
    }

    /**
     * Obtiene todos los empleados.
     *
     * @return Lista de EmpleadoDTO.
     */
    public List<EmpleadoDTO> obtenerTodos() {
        List<Empleado> empleados = empleadoRepository.findAll();
        return empleados.stream()
                .map(this::convertirAEmpleadoDTO)
                .collect(Collectors.toList());
    }

    /**
     * Obtiene un empleado por su identificador �nico.
     *
     * @param id Identificador �nico del empleado.
     * @return EmpleadoDTO correspondiente al ID proporcionado.
     * @throws ResponseStatusException Si no se encuentra el empleado con el ID dado.
     */
    public EmpleadoDTO obtenerPorId(Long id) {
        Empleado empleado = empleadoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Empleado no encontrado con ID: " + id));
        return convertirAEmpleadoDTO(empleado);
    }

    /**
     * Crea un nuevo empleado.
     *
     * @param empleadoDTO DTO que contiene la informaci�n del nuevo empleado.
     * @return EmpleadoDTO del empleado creado.
     */
    public EmpleadoDTO crearEmpleado(EmpleadoDTO empleadoDTO) {
        Empleado empleado = convertirAEmpleadoEntity(empleadoDTO);
        empleado = empleadoRepository.save(empleado);
        return convertirAEmpleadoDTO(empleado);
    }

    /**
     * Actualiza la informaci�n de un empleado existente.
     *
     * @param id          Identificador �nico del empleado a actualizar.
     * @param empleadoDTO DTO con la nueva informaci�n del empleado.
     * @return EmpleadoDTO actualizado.
     * @throws ResponseStatusException Si no se encuentra el empleado con el ID dado.
     */
    public EmpleadoDTO actualizarEmpleado(Long id, EmpleadoDTO empleadoDTO) {
        Empleado empleadoExistente = empleadoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Empleado no encontrado con ID: " + id));

        modelMapper.map(empleadoDTO, empleadoExistente);
        empleadoExistente.setId(id);

        empleadoExistente = empleadoRepository.save(empleadoExistente);
        return convertirAEmpleadoDTO(empleadoExistente);
    }

    /**
     * Elimina un empleado por su identificador �nico.
     *
     * @param id Identificador �nico del empleado a eliminar.
     */
    public void eliminarEmpleado(Long id) {
        empleadoRepository.deleteById(id);
    }

    private EmpleadoDTO convertirAEmpleadoDTO(Empleado empleado) {
        return modelMapper.map(empleado, EmpleadoDTO.class);
    }

    private Empleado convertirAEmpleadoEntity(EmpleadoDTO empleadoDTO) {
        return modelMapper.map(empleadoDTO, Empleado.class);
    }
}
